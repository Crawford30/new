package example.com.sqlitesearch.model;

public class Friend {

    public String Number, Title, Words;

    public Friend(String number, String title, String words) {
        Number = number;
        Title = title;
        Words = words;
    }

    public Friend() {


    }

    public String getNumber() {
        return Number;
    }

    public void setNumber(String number) {
        Number = number;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getWords() {
        return Words;
    }

    public void setWords(String words) {
        Words = words;
    }
}
