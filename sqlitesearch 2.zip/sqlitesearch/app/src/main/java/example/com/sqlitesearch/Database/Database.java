package example.com.sqlitesearch.Database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;
import java.util.List;

import example.com.sqlitesearch.model.Friend;

public class Database extends SQLiteAssetHelper {


    private static final String DB_NAME = "friend.db";
    private static final int DB_VER = 1;

    public Database(Context context) {
        super(context, DB_NAME, null, DB_VER);
    }

    //Function to get all friend

    public List<Friend> getFriends() {
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {"Number", "Title", "Words"};
        String tableName = "Friends";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, null, null, null, null, null);
        List<Friend> result = new ArrayList<>();
        if (((Cursor) cursor).moveToFirst()) {
            Friend friend = new Friend();

            //passing the setter method
            friend.setNumber(cursor.getString(cursor.getColumnIndex("Number")));
            friend.setTitle(cursor.getString(cursor.getColumnIndex("Title")));
            friend.setWords(cursor.getString(cursor.getColumnIndex("Words")));
            do {
                result.add(friend);

            } while (cursor.moveToNext());
        }
        return result;
    }

    //function to get song Title
    public List<String> getTitle() {

        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {"Title"};
        String tableName = "Friends";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, null, null, null, null, null);
        List<String> result = new ArrayList<>();
        if (((Cursor) cursor).moveToFirst()) {
            Friend friend = new Friend();

            //passing the setter method

            do {
                result.add(cursor.getString(cursor.getColumnIndex("Title")));

            } while (cursor.moveToNext());
        }
        return result;

    }

    //Function to get song by name

    public List<String> getSongByName(String Words) {

        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {"Title"};
        String tableName = "Friends";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "Words LIKE?", new String[]{"%" + Words + "%"}, null, null, null);
        List<String> result = new ArrayList<>();
        if (((Cursor) cursor).moveToFirst()) {
            Friend friend = new Friend();

            //passing the setter method

            do {
                result.add(cursor.getString(cursor.getColumnIndex("Title")));

            } while (cursor.moveToNext());
        }
        return result;
    }

}
