package example.com.sqlitesearch.model;

public class Big_Song_Book {
    public String NUMBER, SONG_TITLE, SONG_WORDS;

    public Big_Song_Book(String NUMBER, String SONG_TITLE, String SONG_WORDS) {
        this.NUMBER = NUMBER;
        this.SONG_TITLE = SONG_TITLE;
        this.SONG_WORDS = SONG_WORDS;
    }

    public Big_Song_Book() {
    }

    public String getNUMBER() {
        return NUMBER;
    }

    public String getSONG_TITLE() {
        return SONG_TITLE;
    }

    public String getSONG_WORDS() {
        return SONG_WORDS;
    }
}
